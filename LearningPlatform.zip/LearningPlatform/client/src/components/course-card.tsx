import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Course } from "@shared/schema";
import { BookOpen } from "lucide-react";

interface CourseCardProps {
  course: Course;
  view: "grid" | "list";
}

export default function CourseCard({ course, view }: CourseCardProps) {
  if (view === "grid") {
    return (
      <Card className="flex flex-col h-full overflow-hidden hover:shadow-md transition-shadow">
        <div className="bg-primary/10 h-48 flex items-center justify-center">
          {course.imageUrl ? (
            <div className="w-full h-full flex items-center justify-center overflow-hidden">
              <BookOpen className="h-16 w-16 text-primary" />
            </div>
          ) : (
            <BookOpen className="h-16 w-16 text-primary" />
          )}
        </div>
        <CardHeader className="pb-2 flex-grow">
          <div className="flex justify-between items-start">
            <CardTitle className="text-lg">{course.title}</CardTitle>
          </div>
          <CardDescription className="line-clamp-2">{course.description}</CardDescription>
        </CardHeader>
        <CardContent className="pb-2">
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline">{course.category}</Badge>
            <Badge variant="secondary">{course.skillLevel}</Badge>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" asChild>
            <Link href={`/courses/${course.id}`}>View Course</Link>
          </Button>
        </CardFooter>
      </Card>
    );
  }
  
  // List view
  return (
    <Card className="flex overflow-hidden hover:shadow-md transition-shadow">
      <div className="bg-primary/10 w-56 hidden sm:flex items-center justify-center">
        {course.imageUrl ? (
          <div className="w-full h-full flex items-center justify-center overflow-hidden">
            <BookOpen className="h-16 w-16 text-primary" />
          </div>
        ) : (
          <BookOpen className="h-16 w-16 text-primary" />
        )}
      </div>
      <div className="flex-1 flex flex-col">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <CardTitle>{course.title}</CardTitle>
          </div>
          <CardDescription className="line-clamp-2">{course.description}</CardDescription>
        </CardHeader>
        <CardContent className="pb-2 flex-grow">
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline">{course.category}</Badge>
            <Badge variant="secondary">{course.skillLevel}</Badge>
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild>
            <Link href={`/courses/${course.id}`}>View Course</Link>
          </Button>
        </CardFooter>
      </div>
    </Card>
  );
}
