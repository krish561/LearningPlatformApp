import { useState } from "react";
import { Module } from "@shared/schema";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger 
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2, Circle, BookOpen, CheckSquare } from "lucide-react";

interface CourseContentProps {
  modules: Module[];
  onToggleComplete: (moduleId: number, currentStatus: boolean) => void;
  isModuleCompleted: (moduleId: number) => boolean;
}

export default function CourseContent({ 
  modules, 
  onToggleComplete,
  isModuleCompleted
}: CourseContentProps) {
  const [activeModule, setActiveModule] = useState<string | undefined>(
    modules.length > 0 ? modules[0].id.toString() : undefined
  );

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-6">
        {/* Module Selection */}
        <div className="md:col-span-1">
          <Accordion
            type="single"
            collapsible
            value={activeModule}
            onValueChange={setActiveModule}
            className="border rounded-lg"
          >
            {modules.map((module, index) => {
              const completed = isModuleCompleted(module.id);
              
              return (
                <AccordionItem 
                  key={module.id} 
                  value={module.id.toString()}
                  className="border-b last:border-b-0"
                >
                  <AccordionTrigger className="px-4 hover:no-underline">
                    <div className="flex items-center text-left">
                      <div className="mr-3">
                        {completed ? (
                          <CheckCircle2 className="h-5 w-5 text-green-500" />
                        ) : (
                          <Circle className="h-5 w-5 text-muted-foreground" />
                        )}
                      </div>
                      <div>
                        <span className="text-sm text-muted-foreground block">Module {index + 1}</span>
                        <span className="font-medium">{module.title}</span>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pb-4">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="mt-2 w-full"
                      onClick={() => onToggleComplete(module.id, completed)}
                    >
                      {completed ? (
                        <>
                          <CheckSquare className="h-4 w-4 mr-2" />
                          Mark as Incomplete
                        </>
                      ) : (
                        <>
                          <CheckSquare className="h-4 w-4 mr-2" />
                          Mark as Complete
                        </>
                      )}
                    </Button>
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        </div>
        
        {/* Module Content */}
        <div className="md:col-span-2">
          {activeModule ? (
            modules
              .filter(module => module.id.toString() === activeModule)
              .map(module => {
                const completed = isModuleCompleted(module.id);
                
                return (
                  <Card key={module.id}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-semibold">{module.title}</h2>
                        {completed && (
                          <Badge className="bg-green-500">
                            <CheckCircle2 className="h-3 w-3 mr-1" />
                            Completed
                          </Badge>
                        )}
                      </div>
                      
                      <div className="prose max-w-none">
                        {/* Format content with basic styling */}
                        {module.content.split('\n').map((paragraph, i) => (
                          <p key={i}>{paragraph}</p>
                        ))}
                      </div>
                      
                      <div className="mt-6 flex justify-between">
                        <Button 
                          variant="outline" 
                          disabled={modules.indexOf(module) === 0}
                          onClick={() => {
                            const prevIndex = modules.indexOf(module) - 1;
                            if (prevIndex >= 0) {
                              setActiveModule(modules[prevIndex].id.toString());
                            }
                          }}
                        >
                          Previous Module
                        </Button>
                        
                        <Button 
                          variant={completed ? "outline" : "default"}
                          onClick={() => onToggleComplete(module.id, completed)}
                        >
                          {completed ? (
                            <>
                              <CheckSquare className="h-4 w-4 mr-2" />
                              Mark as Incomplete
                            </>
                          ) : (
                            <>
                              <CheckSquare className="h-4 w-4 mr-2" />
                              Mark as Complete
                            </>
                          )}
                        </Button>
                        
                        <Button 
                          variant="outline"
                          disabled={modules.indexOf(module) === modules.length - 1}
                          onClick={() => {
                            const nextIndex = modules.indexOf(module) + 1;
                            if (nextIndex < modules.length) {
                              setActiveModule(modules[nextIndex].id.toString());
                            }
                          }}
                        >
                          Next Module
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
          ) : (
            <div className="text-center py-12 border rounded-lg">
              <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-medium mb-2">Select a module</h3>
              <p className="text-muted-foreground">
                Choose a module from the list to view its content
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
