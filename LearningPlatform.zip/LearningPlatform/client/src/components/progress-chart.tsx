import { useState, useEffect } from "react";
import { UserProgress, Course } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

interface ProgressChartProps {
  progressData: UserProgress[];
}

export default function ProgressChart({ progressData }: ProgressChartProps) {
  const [activeView, setActiveView] = useState<string>("pie");
  
  // Fetch courses for labels
  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });
  
  // Process data for charts
  const [chartData, setChartData] = useState<any[]>([]);
  const [lineData, setLineData] = useState<any[]>([]);
  
  useEffect(() => {
    if (!progressData || !courses) return;
    
    // Get unique course IDs from progress
    const uniqueCourseIds = [...new Set(progressData.map(p => p.courseId))];
    
    // Calculate completion percentages for each course
    const data = uniqueCourseIds.map(courseId => {
      const course = courses.find(c => c.id === courseId);
      const courseModules = progressData.filter(p => p.courseId === courseId);
      const completedModules = courseModules.filter(p => p.completed).length;
      const totalModules = courseModules.length;
      const completionPercentage = totalModules > 0 ? Math.round((completedModules / totalModules) * 100) : 0;
      
      return {
        name: course?.title || `Course ${courseId}`,
        value: completionPercentage,
        completed: completedModules,
        total: totalModules,
      };
    });
    
    setChartData(data);
    
    // Create timeline data for line chart (simplified mock for demo)
    // In a real app, we would use actual timestamps from completedAt
    const timelineData = uniqueCourseIds.map((courseId, index) => {
      const course = courses.find(c => c.id === courseId);
      const courseModules = progressData.filter(p => p.courseId === courseId);
      const completedModules = courseModules.filter(p => p.completed).length;
      
      return {
        name: course?.title || `Course ${courseId}`,
        completed: completedModules,
        day: index + 1, // Simplified day representation
      };
    });
    
    setLineData(timelineData);
  }, [progressData, courses]);
  
  // Chart colors
  const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];
  
  if (!progressData || progressData.length === 0) {
    return (
      <div className="text-center py-6">
        <p className="text-muted-foreground">No progress data available yet.</p>
      </div>
    );
  }

  return (
    <div>
      <Tabs defaultValue={activeView} onValueChange={setActiveView} className="mb-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pie">Completion</TabsTrigger>
          <TabsTrigger value="bar">Comparison</TabsTrigger>
          <TabsTrigger value="line">Timeline</TabsTrigger>
        </TabsList>
        
        <TabsContent value="pie" className="mt-6">
          {chartData.length > 0 ? (
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value}%`}
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `${value}%`} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <Skeleton className="h-[300px] w-full" />
          )}
        </TabsContent>
        
        <TabsContent value="bar" className="mt-6">
          {chartData.length > 0 ? (
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis label={{ value: 'Completion %', angle: -90, position: 'insideLeft' }} />
                  <Tooltip formatter={(value) => `${value}%`} />
                  <Bar dataKey="value" name="Completion" fill="hsl(var(--primary))">
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <Skeleton className="h-[300px] w-full" />
          )}
        </TabsContent>
        
        <TabsContent value="line" className="mt-6">
          {lineData.length > 0 ? (
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={lineData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" label={{ value: 'Days', position: 'insideBottom', offset: -5 }} />
                  <YAxis label={{ value: 'Modules Completed', angle: -90, position: 'insideLeft' }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="completed" stroke="hsl(var(--primary))" activeDot={{ r: 8 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <Skeleton className="h-[300px] w-full" />
          )}
        </TabsContent>
      </Tabs>
      
      {/* Legend */}
      <div className="flex flex-wrap gap-4 justify-center mt-4">
        {chartData.map((entry, index) => (
          <div key={`legend-${index}`} className="flex items-center">
            <div 
              className="w-3 h-3 mr-2 rounded-full" 
              style={{ backgroundColor: COLORS[index % COLORS.length] }}
            />
            <span className="text-sm">{entry.name}: {entry.completed}/{entry.total} modules</span>
          </div>
        ))}
      </div>
    </div>
  );
}
