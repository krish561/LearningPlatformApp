import { Course } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { BookOpen, ArrowRight } from "lucide-react";

interface RecommendationSectionProps {
  courses: Course[];
}

export default function RecommendationSection({ courses }: RecommendationSectionProps) {
  if (!courses || courses.length === 0) {
    return (
      <div className="text-center py-6">
        <p className="text-muted-foreground">No recommendations available yet.</p>
        <Button asChild variant="link" className="mt-2">
          <Link href="/courses">Browse all courses</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {courses.slice(0, 3).map((course) => (
        <Link key={course.id} href={`/courses/${course.id}`}>
          <Card className="hover:bg-accent transition-colors cursor-pointer">
            <CardContent className="p-4 flex items-center space-x-4">
              <div className="bg-primary/10 h-12 w-12 rounded-full flex items-center justify-center shrink-0">
                <BookOpen className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-medium truncate">{course.title}</h3>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant="outline" className="text-xs">{course.category}</Badge>
                  <Badge variant="secondary" className="text-xs">{course.skillLevel}</Badge>
                </div>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
            </CardContent>
          </Card>
        </Link>
      ))}
      
      {courses.length > 3 && (
        <Button asChild variant="link" className="w-full mt-2">
          <Link href="/courses">View more courses</Link>
        </Button>
      )}
    </div>
  );
}
