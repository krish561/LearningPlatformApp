import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Course, Module, insertCourseSchema, insertModuleSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import PageHeader from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { 
  Settings, 
  PlusCircle,
  Edit,
  Trash2,
  BookOpen,
  AlertTriangle,
  Check
} from "lucide-react";

// Course form schema
const courseFormSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  skillLevel: z.string().min(1, "Skill level is required"),
  category: z.string().min(1, "Category is required"),
  imageUrl: z.string().optional(),
});

// Module form schema
const moduleFormSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  content: z.string().min(10, "Content must be at least 10 characters"),
  orderIndex: z.coerce.number().min(0, "Order is required"),
  courseId: z.coerce.number().min(1, "Course is required"),
});

type CourseFormValues = z.infer<typeof courseFormSchema>;
type ModuleFormValues = z.infer<typeof moduleFormSchema>;

export default function AdminPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("courses");
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [isAddingCourse, setIsAddingCourse] = useState(false);
  const [isAddingModule, setIsAddingModule] = useState(false);
  const [isEditingCourse, setIsEditingCourse] = useState(false);
  const [deletingCourseId, setDeletingCourseId] = useState<number | null>(null);
  
  // Fetch all courses
  const { data: courses, isLoading: isLoadingCourses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });
  
  // Fetch modules for selected course
  const { data: modules, isLoading: isLoadingModules } = useQuery<Module[]>({
    queryKey: [`/api/courses/${selectedCourse?.id}/modules`],
    enabled: !!selectedCourse,
  });
  
  // Course form
  const courseForm = useForm<CourseFormValues>({
    resolver: zodResolver(courseFormSchema),
    defaultValues: {
      title: "",
      description: "",
      skillLevel: "",
      category: "",
      imageUrl: "",
    }
  });
  
  // Module form
  const moduleForm = useForm<ModuleFormValues>({
    resolver: zodResolver(moduleFormSchema),
    defaultValues: {
      title: "",
      content: "",
      orderIndex: 0,
      courseId: 0,
    }
  });
  
  // Reset course form and set defaults if editing
  const resetCourseForm = (course?: Course) => {
    if (course) {
      courseForm.reset({
        title: course.title,
        description: course.description,
        skillLevel: course.skillLevel,
        category: course.category,
        imageUrl: course.imageUrl || "",
      });
    } else {
      courseForm.reset({
        title: "",
        description: "",
        skillLevel: "",
        category: "",
        imageUrl: "",
      });
    }
  };
  
  // Reset module form
  const resetModuleForm = () => {
    moduleForm.reset({
      title: "",
      content: "",
      orderIndex: modules?.length || 0,
      courseId: selectedCourse?.id || 0,
    });
  };
  
  // Create course mutation
  const createCourseMutation = useMutation({
    mutationFn: async (data: CourseFormValues) => {
      const payload = {
        ...data,
        createdBy: user?.id || 0,
      };
      const res = await apiRequest("POST", "/api/courses", payload);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      toast({
        title: "Course created",
        description: "The course has been created successfully",
      });
      setIsAddingCourse(false);
      resetCourseForm();
    },
    onError: (error) => {
      toast({
        title: "Error creating course",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update course mutation
  const updateCourseMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: CourseFormValues }) => {
      const res = await apiRequest("PUT", `/api/courses/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      if (selectedCourse) {
        queryClient.invalidateQueries({ queryKey: [`/api/courses/${selectedCourse.id}`] });
      }
      toast({
        title: "Course updated",
        description: "The course has been updated successfully",
      });
      setIsEditingCourse(false);
    },
    onError: (error) => {
      toast({
        title: "Error updating course",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete course mutation
  const deleteCourseMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/courses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      toast({
        title: "Course deleted",
        description: "The course has been deleted successfully",
      });
      if (selectedCourse && selectedCourse.id === deletingCourseId) {
        setSelectedCourse(null);
      }
      setDeletingCourseId(null);
    },
    onError: (error) => {
      toast({
        title: "Error deleting course",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Create module mutation
  const createModuleMutation = useMutation({
    mutationFn: async (data: ModuleFormValues) => {
      const res = await apiRequest("POST", "/api/modules", data);
      return await res.json();
    },
    onSuccess: () => {
      if (selectedCourse) {
        queryClient.invalidateQueries({ queryKey: [`/api/courses/${selectedCourse.id}/modules`] });
      }
      toast({
        title: "Module created",
        description: "The module has been created successfully",
      });
      setIsAddingModule(false);
      resetModuleForm();
    },
    onError: (error) => {
      toast({
        title: "Error creating module",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Submit course form
  const onSubmitCourse = (values: CourseFormValues) => {
    if (isEditingCourse && selectedCourse) {
      updateCourseMutation.mutate({ id: selectedCourse.id, data: values });
    } else {
      createCourseMutation.mutate(values);
    }
  };
  
  // Submit module form
  const onSubmitModule = (values: ModuleFormValues) => {
    createModuleMutation.mutate(values);
  };
  
  // Handle course selection
  const handleSelectCourse = (course: Course) => {
    setSelectedCourse(course);
    setActiveTab("modules");
  };
  
  // Handle edit course
  const handleEditCourse = (course: Course) => {
    resetCourseForm(course);
    setSelectedCourse(course);
    setIsEditingCourse(true);
  };
  
  // Handle delete course
  const handleDeleteCourse = (id: number) => {
    setDeletingCourseId(id);
  };
  
  // Confirm delete course
  const confirmDeleteCourse = () => {
    if (deletingCourseId) {
      deleteCourseMutation.mutate(deletingCourseId);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader
        title="Admin Dashboard"
        description="Manage courses and educational content"
        icon={<Settings className="h-10 w-10 text-primary" />}
      />
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-8">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="courses">Manage Courses</TabsTrigger>
          <TabsTrigger value="modules" disabled={!selectedCourse}>
            Manage Modules
            {selectedCourse && <span className="ml-2 text-xs opacity-70">({selectedCourse.title})</span>}
          </TabsTrigger>
        </TabsList>
        
        {/* Courses Tab */}
        <TabsContent value="courses" className="mt-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>All Courses</CardTitle>
                  <CardDescription>View and manage all educational courses</CardDescription>
                </div>
                <Button onClick={() => {
                  resetCourseForm();
                  setIsAddingCourse(true);
                  setIsEditingCourse(false);
                }}>
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add Course
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingCourses ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : courses && courses.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Skill Level</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {courses.map((course) => (
                      <TableRow key={course.id}>
                        <TableCell className="font-medium">{course.title}</TableCell>
                        <TableCell>{course.category}</TableCell>
                        <TableCell>{course.skillLevel}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleSelectCourse(course)}
                            >
                              <BookOpen className="h-4 w-4 mr-2" />
                              Modules
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleEditCourse(course)}
                            >
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="text-red-500 hover:text-red-700"
                              onClick={() => handleDeleteCourse(course.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-12 border rounded-lg">
                  <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium mb-2">No courses available</h3>
                  <p className="text-muted-foreground mb-4">
                    Start by adding your first course
                  </p>
                  <Button onClick={() => {
                    resetCourseForm();
                    setIsAddingCourse(true);
                  }}>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Add Course
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Modules Tab */}
        <TabsContent value="modules" className="mt-6">
          {selectedCourse && (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Modules for "{selectedCourse.title}"</CardTitle>
                    <CardDescription>Manage learning modules for this course</CardDescription>
                  </div>
                  <Button onClick={() => {
                    resetModuleForm();
                    setIsAddingModule(true);
                  }}>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Add Module
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingModules ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : modules && modules.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order</TableHead>
                        <TableHead>Title</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {modules.map((module) => (
                        <TableRow key={module.id}>
                          <TableCell>{module.orderIndex}</TableCell>
                          <TableCell className="font-medium">{module.title}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="outline" size="sm">
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="text-red-500 hover:text-red-700"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12 border rounded-lg">
                    <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-medium mb-2">No modules available</h3>
                    <p className="text-muted-foreground mb-4">
                      Start by adding your first module to this course
                    </p>
                    <Button onClick={() => {
                      resetModuleForm();
                      setIsAddingModule(true);
                    }}>
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Add Module
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Add/Edit Course Dialog */}
      <Dialog open={isAddingCourse || isEditingCourse} onOpenChange={(open) => {
        if (!open) {
          setIsAddingCourse(false);
          setIsEditingCourse(false);
        }
      }}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{isEditingCourse ? "Edit Course" : "Add New Course"}</DialogTitle>
            <DialogDescription>
              {isEditingCourse 
                ? "Update the details of this course" 
                : "Fill in the details to create a new course"}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...courseForm}>
            <form onSubmit={courseForm.handleSubmit(onSubmitCourse)} className="space-y-6">
              <FormField
                control={courseForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Course title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={courseForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Course description" rows={4} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={courseForm.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Programming">Programming</SelectItem>
                          <SelectItem value="Design">Design</SelectItem>
                          <SelectItem value="Business">Business</SelectItem>
                          <SelectItem value="Marketing">Marketing</SelectItem>
                          <SelectItem value="Personal Development">Personal Development</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={courseForm.control}
                  name="skillLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Skill Level</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Beginner">Beginner</SelectItem>
                          <SelectItem value="Intermediate">Intermediate</SelectItem>
                          <SelectItem value="Advanced">Advanced</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={courseForm.control}
                name="imageUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Image URL (optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="URL to course image" {...field} />
                    </FormControl>
                    <FormDescription>
                      Provide a URL to an image that represents this course
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button variant="outline" type="button" onClick={() => {
                  setIsAddingCourse(false);
                  setIsEditingCourse(false);
                }}>
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createCourseMutation.isPending || updateCourseMutation.isPending}
                >
                  {(createCourseMutation.isPending || updateCourseMutation.isPending) 
                    ? "Saving..." 
                    : (isEditingCourse ? "Update Course" : "Create Course")}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Add Module Dialog */}
      <Dialog open={isAddingModule} onOpenChange={(open) => {
        if (!open) setIsAddingModule(false);
      }}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Add New Module</DialogTitle>
            <DialogDescription>
              Create a new learning module for this course
            </DialogDescription>
          </DialogHeader>
          
          <Form {...moduleForm}>
            <form onSubmit={moduleForm.handleSubmit(onSubmitModule)} className="space-y-6">
              <FormField
                control={moduleForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Module title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={moduleForm.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Module content" rows={8} {...field} />
                    </FormControl>
                    <FormDescription>
                      Provide the educational content for this module
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={moduleForm.control}
                  name="orderIndex"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Order</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} />
                      </FormControl>
                      <FormDescription>
                        Position in the course (0 = first)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={moduleForm.control}
                  name="courseId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Course</FormLabel>
                      <FormControl>
                        <Input type="hidden" {...field} value={selectedCourse?.id || 0} />
                      </FormControl>
                      <div className="h-10 px-3 py-2 border rounded-md bg-muted">
                        {selectedCourse?.title || "No course selected"}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter>
                <Button variant="outline" type="button" onClick={() => setIsAddingModule(false)}>
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createModuleMutation.isPending}
                >
                  {createModuleMutation.isPending ? "Creating..." : "Create Module"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Course Confirmation */}
      <Dialog open={deletingCourseId !== null} onOpenChange={(open) => {
        if (!open) setDeletingCourseId(null);
      }}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Confirm Deletion
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this course? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Warning</AlertTitle>
            <AlertDescription>
              Deleting this course will also remove all associated modules and student progress.
            </AlertDescription>
          </Alert>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeletingCourseId(null)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={confirmDeleteCourse}
              disabled={deleteCourseMutation.isPending}
            >
              {deleteCourseMutation.isPending ? "Deleting..." : "Delete Course"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
