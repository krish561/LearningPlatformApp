import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Course, Module, UserProgress } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import PageHeader from "@/components/page-header";
import CourseContent from "@/components/course-content";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { 
  BookOpen, 
  ArrowLeft, 
  BarChart, 
  Award, 
  Check,
  CheckCircle2
} from "lucide-react";

export default function CourseDetailPage() {
  const [activeTab, setActiveTab] = useState("content");
  const [match, params] = useRoute("/courses/:id");
  const courseId = parseInt(params?.id || "0");
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Fetch course details
  const { data: course, isLoading: isLoadingCourse } = useQuery<Course>({
    queryKey: [`/api/courses/${courseId}`],
    enabled: !!courseId,
  });
  
  // Fetch course modules
  const { data: modules, isLoading: isLoadingModules } = useQuery<Module[]>({
    queryKey: [`/api/courses/${courseId}/modules`],
    enabled: !!courseId,
  });
  
  // Fetch user progress for this course
  const { data: courseProgress, isLoading: isLoadingProgress } = useQuery<UserProgress[]>({
    queryKey: [`/api/progress/course/${courseId}`],
    enabled: !!courseId,
  });
  
  // Mutation to mark a module as completed
  const markCompletedMutation = useMutation({
    mutationFn: async ({ moduleId, completed }: { moduleId: number, completed: boolean }) => {
      const res = await apiRequest("POST", "/api/progress", {
        courseId,
        moduleId,
        userId: user?.id,
        completed,
        completedAt: completed ? new Date().toISOString() : null
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/progress/course/${courseId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/progress`] });
      toast({
        title: "Progress updated",
        description: "Your progress has been saved",
      });
    },
    onError: (error) => {
      toast({
        title: "Error updating progress",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Calculate course completion percentage
  const completionPercentage = calculateCompletionPercentage(modules, courseProgress);
  
  // Handle marking a module as completed/uncompleted
  const handleToggleCompletion = (moduleId: number, currentStatus: boolean) => {
    markCompletedMutation.mutate({ 
      moduleId, 
      completed: !currentStatus 
    });
  };
  
  // Check if a module is completed
  const isModuleCompleted = (moduleId: number) => {
    return courseProgress?.some(p => p.moduleId === moduleId && p.completed) || false;
  };
  
  if (isLoadingCourse || !course) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-6">
          <Skeleton className="h-12 w-3/4" />
          <Skeleton className="h-6 w-1/2" />
          <Skeleton className="h-64 w-full rounded-lg" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/courses">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Courses
          </Link>
        </Button>
      </div>
      
      <PageHeader
        title={course.title}
        description={course.description}
        icon={<BookOpen className="h-10 w-10 text-primary" />}
      />
      
      <div className="mt-6 flex flex-wrap gap-3">
        <Badge variant="outline">{course.category}</Badge>
        <Badge variant="secondary">{course.skillLevel}</Badge>
      </div>
      
      <div className="mt-8 bg-card rounded-lg border p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <BarChart className="h-5 w-5 text-muted-foreground" />
            <h3 className="font-medium">Your Progress</h3>
          </div>
          {completionPercentage === 100 && (
            <Badge className="bg-green-500">
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Completed
            </Badge>
          )}
        </div>
        <Progress value={completionPercentage} className="h-2" />
        <p className="text-sm text-muted-foreground mt-2">
          {isLoadingModules ? (
            <Skeleton className="h-4 w-32 inline-block" />
          ) : (
            `${courseProgress?.filter(p => p.completed).length || 0} of ${modules?.length || 0} modules completed (${completionPercentage}%)`
          )}
        </p>
      </div>
      
      <div className="mt-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="content">Course Content</TabsTrigger>
            <TabsTrigger value="info">Course Information</TabsTrigger>
          </TabsList>
          
          <TabsContent value="content" className="mt-6">
            {isLoadingModules ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))}
              </div>
            ) : modules?.length ? (
              <CourseContent 
                modules={modules} 
                onToggleComplete={handleToggleCompletion}
                isModuleCompleted={isModuleCompleted}
              />
            ) : (
              <div className="text-center py-12 border rounded-lg">
                <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No content available</h3>
                <p className="text-muted-foreground">
                  This course doesn't have any modules yet
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="info" className="mt-6">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-2">About this Course</h3>
                <p className="text-muted-foreground">{course.description}</p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-semibold mb-2">What You'll Learn</h3>
                <ul className="space-y-2">
                  {isLoadingModules ? (
                    [...Array(4)].map((_, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <Check className="h-5 w-5 text-primary" />
                        <Skeleton className="h-4 w-full" />
                      </li>
                    ))
                  ) : modules?.map(module => (
                    <li key={module.id} className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-primary" />
                      <span>{module.title}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Requirements</h3>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>No previous knowledge required - we'll teach you everything you need to know</li>
                  <li>A desire to learn and improve your skills</li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Helper function to calculate completion percentage
function calculateCompletionPercentage(
  modules?: Module[], 
  progress?: UserProgress[]
): number {
  if (!modules?.length || !progress?.length) return 0;
  
  const completedModules = progress.filter(p => p.completed).length;
  return Math.round((completedModules / modules.length) * 100);
}
