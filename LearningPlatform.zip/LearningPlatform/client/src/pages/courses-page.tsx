import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Course } from "@shared/schema";
import CourseCard from "@/components/course-card";
import PageHeader from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { BookOpen, Search, Filter } from "lucide-react";

const SKILL_LEVELS = ["Beginner", "Intermediate", "Advanced"];
const CATEGORIES = ["Data Science", "Web Development", "Mobile Development", "Blockchain", "Programming", "Design", "Business", "Marketing", "Personal Development"];

export default function CoursesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("_all");
  const [selectedSkillLevel, setSelectedSkillLevel] = useState<string>("_all");
  
  // Query parameters based on filters
  const queryParams = new URLSearchParams();
  if (selectedCategory && selectedCategory !== "_all") queryParams.append("category", selectedCategory);
  if (selectedSkillLevel && selectedSkillLevel !== "_all") queryParams.append("skillLevel", selectedSkillLevel);
  
  // Fetch courses with potential filters
  const { data: courses, isLoading } = useQuery<Course[]>({
    queryKey: [`/api/courses?${queryParams.toString()}`],
  });
  
  // Filter courses by search term
  const filteredCourses = courses?.filter(course => 
    course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Reset filters function
  const resetFilters = () => {
    setSearchTerm("");
    setSelectedCategory("_all");
    setSelectedSkillLevel("_all");
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader
        title="Browse Courses"
        description="Discover courses tailored to your learning needs"
        icon={<BookOpen className="h-10 w-10 text-primary" />}
      />
      
      {/* Search and Filters */}
      <div className="mt-8 mb-6 space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search courses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <div className="flex gap-4">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="_all">All Categories</SelectItem>
                {CATEGORIES.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedSkillLevel} onValueChange={setSelectedSkillLevel}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Skill Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="_all">All Levels</SelectItem>
                {SKILL_LEVELS.map(level => (
                  <SelectItem key={level} value={level}>{level}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Active filters */}
        {((selectedCategory && selectedCategory !== "_all") || 
          (selectedSkillLevel && selectedSkillLevel !== "_all") || 
          searchTerm) && (
          <div className="flex items-center gap-2 flex-wrap">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Active filters:</span>
            
            {selectedCategory && selectedCategory !== "_all" && (
              <Button 
                variant="outline" 
                size="sm" 
                className="h-7 text-xs rounded-full"
                onClick={() => setSelectedCategory("_all")}
              >
                Category: {selectedCategory} ×
              </Button>
            )}
            
            {selectedSkillLevel && selectedSkillLevel !== "_all" && (
              <Button 
                variant="outline" 
                size="sm" 
                className="h-7 text-xs rounded-full"
                onClick={() => setSelectedSkillLevel("_all")}
              >
                Level: {selectedSkillLevel} ×
              </Button>
            )}
            
            {searchTerm && (
              <Button 
                variant="outline" 
                size="sm" 
                className="h-7 text-xs rounded-full"
                onClick={() => setSearchTerm("")}
              >
                Search: {searchTerm} ×
              </Button>
            )}
            
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-7 text-xs ml-auto"
              onClick={resetFilters}
            >
              Clear all
            </Button>
          </div>
        )}
      </div>
      
      {/* Course Listing */}
      <div className="mt-6">
        <Tabs defaultValue="grid" className="mb-8">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">
              {isLoading ? (
                <Skeleton className="h-7 w-40" />
              ) : (
                `Showing ${filteredCourses?.length || 0} courses`
              )}
            </h2>
            <TabsList>
              <TabsTrigger value="grid">Grid</TabsTrigger>
              <TabsTrigger value="list">List</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="grid" className="mt-6">
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="flex flex-col gap-2">
                    <Skeleton className="h-48 w-full rounded-lg" />
                    <Skeleton className="h-6 w-2/3" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                ))}
              </div>
            ) : filteredCourses?.length ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCourses.map(course => (
                  <CourseCard key={course.id} course={course} view="grid" />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No courses found</h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search or filters
                </p>
                <Button onClick={resetFilters}>
                  Clear Filters
                </Button>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="list" className="mt-6">
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="flex gap-4">
                    <Skeleton className="h-32 w-56 rounded-lg" />
                    <div className="flex-1 flex flex-col gap-2">
                      <Skeleton className="h-6 w-2/3" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-3/4" />
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredCourses?.length ? (
              <div className="space-y-4">
                {filteredCourses.map(course => (
                  <CourseCard key={course.id} course={course} view="list" />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No courses found</h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search or filters
                </p>
                <Button onClick={resetFilters}>
                  Clear Filters
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
