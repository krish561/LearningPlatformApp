import { useQuery } from "@tanstack/react-query";
import { Course, UserProgress } from "@shared/schema";
import { Link } from "wouter";
import PageHeader from "@/components/page-header";
import CourseCard from "@/components/course-card";
import RecommendationSection from "@/components/recommendation-section";
import ProgressChart from "@/components/progress-chart";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { BookOpen, Award, BarChart } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function HomePage() {
  const { user } = useAuth();
  
  const { data: userProgress, isLoading: isProgressLoading } = useQuery<UserProgress[]>({
    queryKey: ["/api/progress"],
  });
  
  // Get recommendations 
  const { data: recommendedCourses, isLoading: isRecommendationsLoading } = useQuery<Course[]>({
    queryKey: ["/api/recommendations"],
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader 
        title={`Welcome back, ${user?.username}!`}
        description="Track your progress and continue your learning journey"
        icon={<Award className="h-10 w-10 text-primary" />}
      />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        {/* Learning Stats */}
        <Card className="md:col-span-2 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart className="h-5 w-5" />
              Your Learning Progress
            </CardTitle>
            <CardDescription>
              Track your learning journey across all courses
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isProgressLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-[200px] w-full" />
              </div>
            ) : userProgress && userProgress.length > 0 ? (
              <ProgressChart progressData={userProgress} />
            ) : (
              <div className="text-center py-8">
                <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No progress yet</h3>
                <p className="text-muted-foreground mb-4">
                  Start a course to begin tracking your progress
                </p>
                <Button asChild>
                  <Link href="/courses">Browse Courses</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recommendations Card */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Recommended for You
            </CardTitle>
            <CardDescription>
              Based on your interests and progress
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isRecommendationsLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
              </div>
            ) : recommendedCourses?.length ? (
              <RecommendationSection courses={recommendedCourses} />
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground">
                  Start exploring courses to get personalized recommendations
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="mt-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Quick Actions</h2>
          <Button asChild variant="outline">
            <Link href="/courses">View All Courses</Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          <Link href="/courses">
            <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
              <CardContent className="p-6 text-center">
                <BookOpen className="h-10 w-10 mx-auto mb-4 text-primary" />
                <h3 className="text-lg font-medium mb-2">Browse Courses</h3>
                <p className="text-sm text-muted-foreground">
                  Explore our catalog of courses
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/profile">
            <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
              <CardContent className="p-6 text-center">
                <BarChart className="h-10 w-10 mx-auto mb-4 text-primary" />
                <h3 className="text-lg font-medium mb-2">View Progress</h3>
                <p className="text-sm text-muted-foreground">
                  Track your learning achievements
                </p>
              </CardContent>
            </Card>
          </Link>

          {user?.role === "admin" && (
            <Link href="/admin">
              <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                <CardContent className="p-6 text-center">
                  <Award className="h-10 w-10 mx-auto mb-4 text-primary" />
                  <h3 className="text-lg font-medium mb-2">Admin Panel</h3>
                  <p className="text-sm text-muted-foreground">
                    Manage courses and content
                  </p>
                </CardContent>
              </Card>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
