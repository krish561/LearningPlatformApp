import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { UserProgress, Course } from "@shared/schema";
import PageHeader from "@/components/page-header";
import ProgressChart from "@/components/progress-chart";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { UserCircle, BookOpen, Award, BarChart3, Clock, BookMarked } from "lucide-react";

export default function ProfilePage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");
  
  // Fetch user progress
  const { data: userProgress, isLoading: isProgressLoading } = useQuery<UserProgress[]>({
    queryKey: ["/api/progress"],
  });
  
  // Fetch all courses for reference
  const { data: courses, isLoading: isCoursesLoading } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });
  
  // Calculate completed courses
  const completedCourses = calculateCompletedCourses(userProgress, courses);
  
  // Get courses in progress
  const coursesInProgress = calculateCoursesInProgress(userProgress, courses, completedCourses);
  
  // Format user's initials for avatar
  const getInitials = (username: string) => {
    return username.substring(0, 2).toUpperCase();
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader
        title="My Profile"
        description="Track your learning journey and achievements"
        icon={<UserCircle className="h-10 w-10 text-primary" />}
      />
      
      {/* Profile Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <Card className="md:col-span-1">
          <CardContent className="pt-6 flex flex-col items-center">
            <Avatar className="h-24 w-24 mb-4">
              <AvatarFallback className="text-lg bg-primary text-primary-foreground">
                {user ? getInitials(user.username) : "..."}
              </AvatarFallback>
            </Avatar>
            
            <h2 className="text-xl font-bold mb-1">{user?.username}</h2>
            <p className="text-muted-foreground mb-4">{user?.email}</p>
            
            <div className="flex flex-wrap gap-2 justify-center mb-6">
              <Badge variant="outline">{user?.role}</Badge>
              <Badge className="bg-primary">Active Learner</Badge>
            </div>
            
            <div className="w-full space-y-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <BookMarked className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Enrolled Courses</span>
                </div>
                <span className="font-medium">
                  {isProgressLoading ? (
                    <Skeleton className="h-4 w-8 inline-block" />
                  ) : (
                    getEnrolledCoursesCount(userProgress)
                  )}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Award className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Completed Courses</span>
                </div>
                <span className="font-medium">
                  {isProgressLoading ? (
                    <Skeleton className="h-4 w-8 inline-block" />
                  ) : (
                    completedCourses.length
                  )}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">In Progress</span>
                </div>
                <span className="font-medium">
                  {isProgressLoading ? (
                    <Skeleton className="h-4 w-8 inline-block" />
                  ) : (
                    coursesInProgress.length
                  )}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Learning Progress</CardTitle>
            <CardDescription>
              Your overall progress across all courses
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isProgressLoading ? (
              <Skeleton className="h-[200px] w-full" />
            ) : userProgress && userProgress.length > 0 ? (
              <ProgressChart progressData={userProgress} />
            ) : (
              <div className="text-center py-8">
                <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No progress yet</h3>
                <p className="text-muted-foreground mb-4">
                  Start a course to begin tracking your progress
                </p>
                <Button asChild>
                  <Link href="/courses">Browse Courses</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Course Progress Tabs */}
      <div className="mt-12">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
            <TabsTrigger value="in-progress">In Progress</TabsTrigger>
          </TabsList>
          
          {/* Overview Tab */}
          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Recently Accessed */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Recently Accessed
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isProgressLoading || isCoursesLoading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <Skeleton key={i} className="h-16 w-full" />
                      ))}
                    </div>
                  ) : coursesInProgress.length > 0 ? (
                    <div className="space-y-4">
                      {coursesInProgress.slice(0, 3).map(course => (
                        <Link key={course.id} href={`/courses/${course.id}`}>
                          <div className="flex gap-4 p-3 border rounded-lg hover:bg-accent hover:cursor-pointer transition-colors">
                            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                              <BookOpen className="h-6 w-6 text-primary" />
                            </div>
                            <div>
                              <h3 className="font-medium">{course.title}</h3>
                              <p className="text-sm text-muted-foreground">{course.category} • {course.skillLevel}</p>
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-muted-foreground">
                        You haven't started any courses yet
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              {/* Achievements */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="h-5 w-5" />
                    Achievements
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isProgressLoading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <Skeleton key={i} className="h-16 w-full" />
                      ))}
                    </div>
                  ) : completedCourses.length > 0 ? (
                    <div className="space-y-4">
                      {completedCourses.map(course => (
                        <div key={course.id} className="flex gap-4 p-3 border rounded-lg">
                          <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                            <Award className="h-6 w-6 text-green-500" />
                          </div>
                          <div>
                            <h3 className="font-medium">Completed: {course.title}</h3>
                            <p className="text-sm text-muted-foreground">{course.category} • {course.skillLevel}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-muted-foreground">
                        Complete courses to earn achievements
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Completed Tab */}
          <TabsContent value="completed" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Completed Courses</CardTitle>
                <CardDescription>
                  Courses you have successfully completed
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isProgressLoading || isCoursesLoading ? (
                  <div className="space-y-4">
                    {[...Array(4)].map((_, i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : completedCourses.length > 0 ? (
                  <div className="space-y-4">
                    {completedCourses.map(course => (
                      <Link key={course.id} href={`/courses/${course.id}`}>
                        <div className="flex gap-4 p-4 border rounded-lg hover:bg-accent hover:cursor-pointer transition-colors">
                          <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                            <Award className="h-6 w-6 text-green-500" />
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between items-start">
                              <h3 className="font-medium">{course.title}</h3>
                              <Badge className="bg-green-500">Completed</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">{course.category} • {course.skillLevel}</p>
                            <p className="text-sm mt-2 line-clamp-2">{course.description}</p>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Award className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-medium mb-2">No completed courses yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Continue working on your courses to complete them
                    </p>
                    <Button asChild>
                      <Link href="/courses">Browse Courses</Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* In Progress Tab */}
          <TabsContent value="in-progress" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Courses In Progress</CardTitle>
                <CardDescription>
                  Continue learning where you left off
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isProgressLoading || isCoursesLoading ? (
                  <div className="space-y-4">
                    {[...Array(4)].map((_, i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : coursesInProgress.length > 0 ? (
                  <div className="space-y-4">
                    {coursesInProgress.map(course => {
                      const progress = calculateCourseProgressPercentage(userProgress, course.id, courses);
                      
                      return (
                        <Link key={course.id} href={`/courses/${course.id}`}>
                          <div className="flex gap-4 p-4 border rounded-lg hover:bg-accent hover:cursor-pointer transition-colors">
                            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                              <BookOpen className="h-6 w-6 text-primary" />
                            </div>
                            <div className="flex-1">
                              <div className="flex justify-between items-start">
                                <h3 className="font-medium">{course.title}</h3>
                                <Badge variant="outline">{progress}% Complete</Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mt-1">{course.category} • {course.skillLevel}</p>
                              <div className="mt-3 bg-muted rounded-full h-2">
                                <div 
                                  className="bg-primary h-full rounded-full" 
                                  style={{ width: `${progress}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-medium mb-2">No courses in progress</h3>
                    <p className="text-muted-foreground mb-4">
                      Start learning by enrolling in a course
                    </p>
                    <Button asChild>
                      <Link href="/courses">Browse Courses</Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Helper function to get enrolled courses count
function getEnrolledCoursesCount(userProgress?: UserProgress[]): number {
  if (!userProgress?.length) return 0;
  
  // Get unique course IDs from progress
  const uniqueCourseIds = new Set(userProgress.map(progress => progress.courseId));
  return uniqueCourseIds.size;
}

// Helper function to calculate completed courses
function calculateCompletedCourses(
  userProgress?: UserProgress[], 
  courses?: Course[]
): Course[] {
  if (!userProgress?.length || !courses?.length) return [];
  
  // Get unique course IDs
  const uniqueCourseIds = new Set(userProgress.map(progress => progress.courseId));
  const completedCourseIds = new Set<number>();
  
  // Check which courses are completed
  uniqueCourseIds.forEach(courseId => {
    // Get modules for this course by filtering progress
    const courseProgress = userProgress.filter(p => p.courseId === courseId);
    
    // Get module count for this course
    const courseModules = courses.filter(c => c.id === courseId);
    
    if (courseModules.length && courseProgress.length) {
      // If all modules are completed, course is completed
      const allModulesCompleted = courseProgress.every(p => p.completed);
      if (allModulesCompleted) {
        completedCourseIds.add(courseId);
      }
    }
  });
  
  // Return completed courses
  return courses.filter(course => completedCourseIds.has(course.id));
}

// Helper function to calculate courses in progress
function calculateCoursesInProgress(
  userProgress?: UserProgress[], 
  courses?: Course[],
  completedCourses?: Course[]
): Course[] {
  if (!userProgress?.length || !courses?.length) return [];
  
  const completedCourseIds = new Set(completedCourses?.map(c => c.id) || []);
  
  // Get unique course IDs from progress
  const uniqueCourseIds = new Set(userProgress.map(progress => progress.courseId));
  
  // Filter out completed courses
  const inProgressCourseIds = Array.from(uniqueCourseIds).filter(id => !completedCourseIds.has(id));
  
  // Return in-progress courses
  return courses.filter(course => inProgressCourseIds.includes(course.id));
}

// Helper function to calculate course progress percentage
function calculateCourseProgressPercentage(
  userProgress?: UserProgress[], 
  courseId?: number,
  courses?: Course[]
): number {
  if (!userProgress?.length || !courseId) return 0;
  
  // Get progress for this course
  const courseProgress = userProgress.filter(p => p.courseId === courseId);
  
  if (!courseProgress.length) return 0;
  
  // Calculate percentage
  const completedModules = courseProgress.filter(p => p.completed).length;
  const totalModules = courseProgress.length;
  
  return Math.round((completedModules / totalModules) * 100);
}
