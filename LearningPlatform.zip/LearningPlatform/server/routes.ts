import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertCourseSchema, 
  insertModuleSchema, 
  insertUserProgressSchema 
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Middleware to check if user is authenticated
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Middleware to check if user is an admin
  const requireAdmin = (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.status(403).json({ message: "Admin privileges required" });
    }
    next();
  };

  // Course routes
  app.get("/api/courses", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      const skillLevel = req.query.skillLevel as string | undefined;
      
      let courses;
      if (category) {
        courses = await storage.getCoursesByCategory(category);
      } else if (skillLevel) {
        courses = await storage.getCoursesBySkillLevel(skillLevel);
      } else {
        courses = await storage.getCourses();
      }
      
      res.json(courses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.get("/api/courses/:id", async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const course = await storage.getCourse(courseId);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(course);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });

  app.post("/api/courses", requireAdmin, async (req, res) => {
    try {
      const courseData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(courseData);
      res.status(201).json(course);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid course data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create course" });
    }
  });

  app.put("/api/courses/:id", requireAdmin, async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const courseData = insertCourseSchema.partial().parse(req.body);
      
      const updatedCourse = await storage.updateCourse(courseId, courseData);
      if (!updatedCourse) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(updatedCourse);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid course data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update course" });
    }
  });

  app.delete("/api/courses/:id", requireAdmin, async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const deleted = await storage.deleteCourse(courseId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete course" });
    }
  });

  // Module routes
  app.get("/api/courses/:courseId/modules", async (req, res) => {
    try {
      const courseId = parseInt(req.params.courseId);
      const modules = await storage.getModules(courseId);
      res.json(modules);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch modules" });
    }
  });

  app.get("/api/modules/:id", async (req, res) => {
    try {
      const moduleId = parseInt(req.params.id);
      const module = await storage.getModule(moduleId);
      
      if (!module) {
        return res.status(404).json({ message: "Module not found" });
      }
      
      res.json(module);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch module" });
    }
  });

  app.post("/api/modules", requireAdmin, async (req, res) => {
    try {
      const moduleData = insertModuleSchema.parse(req.body);
      const module = await storage.createModule(moduleData);
      res.status(201).json(module);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid module data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create module" });
    }
  });

  app.put("/api/modules/:id", requireAdmin, async (req, res) => {
    try {
      const moduleId = parseInt(req.params.id);
      const moduleData = insertModuleSchema.partial().parse(req.body);
      
      const updatedModule = await storage.updateModule(moduleId, moduleData);
      if (!updatedModule) {
        return res.status(404).json({ message: "Module not found" });
      }
      
      res.json(updatedModule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid module data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update module" });
    }
  });

  app.delete("/api/modules/:id", requireAdmin, async (req, res) => {
    try {
      const moduleId = parseInt(req.params.id);
      const deleted = await storage.deleteModule(moduleId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Module not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete module" });
    }
  });

  // Progress routes
  app.get("/api/progress", requireAuth, async (req, res) => {
    try {
      const userId = req.user.id;
      const progress = await storage.getUserProgress(userId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch progress" });
    }
  });

  app.get("/api/progress/course/:courseId", requireAuth, async (req, res) => {
    try {
      const userId = req.user.id;
      const courseId = parseInt(req.params.courseId);
      const progress = await storage.getCourseProgress(userId, courseId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch course progress" });
    }
  });

  app.post("/api/progress", requireAuth, async (req, res) => {
    try {
      // Override userId with the authenticated user's ID
      const progressData = insertUserProgressSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const progress = await storage.createOrUpdateProgress(progressData);
      res.status(201).json(progress);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid progress data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update progress" });
    }
  });

  // Recommendations route
  app.get("/api/recommendations", requireAuth, async (req, res) => {
    try {
      // For MVP, we'll implement a simple recommendation system:
      // 1. Get all courses
      // 2. Get user's completed courses (from progress)
      // 3. Recommend courses the user hasn't completed yet in the same categories they've shown interest in
      const userId = req.user.id;
      const allCourses = await storage.getCourses();
      const userProgress = await storage.getUserProgress(userId);
      
      // Get completed course IDs
      const completedCourseIds = new Set<number>();
      const courseCategories = new Set<string>();
      
      // For each course with progress
      for (const progress of userProgress) {
        const course = allCourses.find(c => c.id === progress.courseId);
        if (course) {
          // Get modules for this course
          const modules = await storage.getModules(course.id);
          
          // Check if all modules are completed
          const moduleProgressItems = userProgress.filter(p => 
            p.courseId === course.id && p.completed
          );
          
          // If all modules are completed, mark course as completed
          if (moduleProgressItems.length === modules.length) {
            completedCourseIds.add(course.id);
          }
          
          // Add category to interests
          courseCategories.add(course.category);
        }
      }
      
      // Filter recommendations
      let recommendations = allCourses.filter(course => 
        !completedCourseIds.has(course.id) && 
        courseCategories.has(course.category)
      );
      
      // If no recommendations based on categories (new user), return top courses
      if (recommendations.length === 0) {
        recommendations = allCourses.slice(0, 3);
      }
      
      // Limit to 5 recommendations
      recommendations = recommendations.slice(0, 5);
      
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate recommendations" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
