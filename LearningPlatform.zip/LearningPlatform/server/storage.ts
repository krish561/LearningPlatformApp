import { 
  users, type User, type InsertUser,
  courses, type Course, type InsertCourse,
  modules, type Module, type InsertModule,
  userProgress, type UserProgress, type InsertUserProgress
} from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

// Define SessionStore type
type SessionStore = session.Store;

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Course methods
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getCoursesByCategory(category: string): Promise<Course[]>;
  getCoursesBySkillLevel(skillLevel: string): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: Partial<InsertCourse>): Promise<Course | undefined>;
  deleteCourse(id: number): Promise<boolean>;
  
  // Module methods
  getModules(courseId: number): Promise<Module[]>;
  getModule(id: number): Promise<Module | undefined>;
  createModule(module: InsertModule): Promise<Module>;
  updateModule(id: number, module: Partial<InsertModule>): Promise<Module | undefined>;
  deleteModule(id: number): Promise<boolean>;
  
  // Progress methods
  getUserProgress(userId: number): Promise<UserProgress[]>;
  getModuleProgress(userId: number, moduleId: number): Promise<UserProgress | undefined>;
  getCourseProgress(userId: number, courseId: number): Promise<UserProgress[]>;
  createOrUpdateProgress(progress: InsertUserProgress): Promise<UserProgress>;
  
  // Session store
  sessionStore: SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private courses: Map<number, Course>;
  private modules: Map<number, Module>;
  private progress: Map<number, UserProgress>;
  
  private userIdCounter: number;
  private courseIdCounter: number;
  private moduleIdCounter: number;
  private progressIdCounter: number;
  
  sessionStore: SessionStore;

  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.modules = new Map();
    this.progress = new Map();
    
    this.userIdCounter = 1;
    this.courseIdCounter = 1;
    this.moduleIdCounter = 1;
    this.progressIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Initialize with an admin user
    this.createUser({
      username: "admin",
      password: "adminpassword", // This will be hashed in auth.ts
      email: "admin@example.com",
      role: "admin"
    }).then(admin => {
      // Add dummy courses
      this.addDummyCourses(admin.id);
    });
  }
  
  // Helper method to create dummy courses and modules
  private async addDummyCourses(adminId: number) {
    // Course 1: Machine Learning Fundamentals
    const mlCourse = await this.createCourse({
      title: "Machine Learning Fundamentals",
      description: "Learn the basics of machine learning algorithms, techniques, and practical applications. This course covers supervised and unsupervised learning methods.",
      skillLevel: "Intermediate",
      category: "Data Science",
      createdBy: adminId,
      imageUrl: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?q=80&w=2070"
    });
    
    // Modules for Machine Learning course
    await this.createModule({
      courseId: mlCourse.id,
      title: "Introduction to Machine Learning",
      content: "This module introduces you to the fundamental concepts of machine learning, including the difference between supervised and unsupervised learning, common algorithms, and basic terminology.",
      orderIndex: 1
    });
    
    await this.createModule({
      courseId: mlCourse.id,
      title: "Linear Regression and Gradient Descent",
      content: "Understanding linear regression as a fundamental algorithm for predictive modeling and how gradient descent optimizes the model parameters to minimize error.",
      orderIndex: 2
    });
    
    await this.createModule({
      courseId: mlCourse.id,
      title: "Classification Algorithms",
      content: "Explore popular classification algorithms including logistic regression, decision trees, and K-nearest neighbors, along with evaluation metrics like precision and recall.",
      orderIndex: 3
    });
    
    // Course 2: Web Development with React
    const reactCourse = await this.createCourse({
      title: "Web Development with React",
      description: "Master modern frontend development with React. Learn component-based architecture, state management, hooks, and how to build responsive user interfaces.",
      skillLevel: "Beginner",
      category: "Web Development",
      createdBy: adminId,
      imageUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=2070"
    });
    
    // Modules for React course
    await this.createModule({
      courseId: reactCourse.id,
      title: "React Fundamentals",
      content: "Learn the core concepts of React including components, JSX syntax, and the virtual DOM. Set up your development environment and create your first React application.",
      orderIndex: 1
    });
    
    await this.createModule({
      courseId: reactCourse.id,
      title: "State and Props",
      content: "Understand the difference between state and props, how to manage component state, and passing data between components using props.",
      orderIndex: 2
    });
    
    await this.createModule({
      courseId: reactCourse.id,
      title: "React Hooks",
      content: "Learn how to use React Hooks like useState, useEffect, useContext, and create custom hooks to manage state and side effects in functional components.",
      orderIndex: 3
    });
    
    // Course 3: Python for Data Analysis
    const pythonCourse = await this.createCourse({
      title: "Python for Data Analysis",
      description: "Learn to use Python libraries like Pandas, NumPy, and Matplotlib to analyze and visualize data. Perfect for aspiring data analysts and scientists.",
      skillLevel: "Beginner",
      category: "Data Science",
      createdBy: adminId,
      imageUrl: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?q=80&w=2062"
    });
    
    // Modules for Python course
    await this.createModule({
      courseId: pythonCourse.id,
      title: "Introduction to Python for Data Science",
      content: "An introduction to Python programming language basics and why it's widely used in data science. Learn about data types, variables, control structures, and functions.",
      orderIndex: 1
    });
    
    await this.createModule({
      courseId: pythonCourse.id,
      title: "Data Manipulation with Pandas",
      content: "Master the Pandas library for efficient data manipulation. Learn about DataFrames, Series, indexing, filtering, and transforming datasets.",
      orderIndex: 2
    });
    
    await this.createModule({
      courseId: pythonCourse.id,
      title: "Data Visualization with Matplotlib and Seaborn",
      content: "Create compelling visualizations using Matplotlib and Seaborn. Learn to create various chart types, customize plots, and communicate insights effectively through data visualization.",
      orderIndex: 3
    });
    
    // Course 4: Mobile App Development with Flutter
    const flutterCourse = await this.createCourse({
      title: "Mobile App Development with Flutter",
      description: "Build cross-platform mobile apps for iOS and Android using Google's Flutter framework. Learn Dart programming and create beautiful, responsive UIs.",
      skillLevel: "Intermediate",
      category: "Mobile Development",
      createdBy: adminId,
      imageUrl: "https://images.unsplash.com/photo-1551650975-87deedd944c3?q=80&w=1974"
    });
    
    // Modules for Flutter course
    await this.createModule({
      courseId: flutterCourse.id,
      title: "Getting Started with Flutter and Dart",
      content: "Set up your development environment, learn the basics of Dart programming language, and understand Flutter's architecture and widget system.",
      orderIndex: 1
    });
    
    await this.createModule({
      courseId: flutterCourse.id,
      title: "Building Responsive UIs",
      content: "Create beautiful and responsive user interfaces using Flutter's rich widget library. Learn about layout widgets, styling, and handling user input.",
      orderIndex: 2
    });
    
    await this.createModule({
      courseId: flutterCourse.id,
      title: "State Management in Flutter",
      content: "Explore various state management approaches in Flutter applications, including setState, Provider, and Bloc patterns. Learn when to use each approach.",
      orderIndex: 3
    });
    
    // Course 5: Blockchain and Cryptocurrency
    const blockchainCourse = await this.createCourse({
      title: "Blockchain and Cryptocurrency Fundamentals",
      description: "Understanding blockchain technology, smart contracts, and the cryptocurrency ecosystem. Learn how blockchain is revolutionizing industries beyond finance.",
      skillLevel: "Advanced",
      category: "Blockchain",
      createdBy: adminId,
      imageUrl: "https://images.unsplash.com/photo-1639152201720-5e536d254d81?q=80&w=1932"
    });
    
    // Modules for Blockchain course
    await this.createModule({
      courseId: blockchainCourse.id,
      title: "Blockchain Fundamentals",
      content: "Understand the core concepts of blockchain technology including distributed ledgers, consensus mechanisms, and cryptographic hashing.",
      orderIndex: 1
    });
    
    await this.createModule({
      courseId: blockchainCourse.id,
      title: "Smart Contracts and Ethereum",
      content: "Explore the Ethereum platform and learn to develop smart contracts using Solidity. Understand how smart contracts enable decentralized applications (dApps).",
      orderIndex: 2
    });
    
    await this.createModule({
      courseId: blockchainCourse.id,
      title: "Cryptocurrency Economics",
      content: "Learn about cryptocurrency tokenomics, market dynamics, and the economic principles behind different token models and blockchain ecosystems.",
      orderIndex: 3
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: now,
      role: insertUser.role || "user" // Ensure role is always defined
    };
    this.users.set(id, user);
    return user;
  }
  
  // Course methods
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }
  
  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }
  
  async getCoursesByCategory(category: string): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(
      (course) => course.category === category
    );
  }
  
  async getCoursesBySkillLevel(skillLevel: string): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(
      (course) => course.skillLevel === skillLevel
    );
  }
  
  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = this.courseIdCounter++;
    const now = new Date();
    // First, create a plain object with all properties explicitly defined to match Course type
    const course: Course = {
      id,
      title: insertCourse.title,
      description: insertCourse.description,
      skillLevel: insertCourse.skillLevel,
      category: insertCourse.category,
      createdBy: insertCourse.createdBy,
      imageUrl: insertCourse.imageUrl || null,
      createdAt: now
    };
    this.courses.set(id, course);
    return course;
  }
  
  async updateCourse(id: number, courseUpdate: Partial<InsertCourse>): Promise<Course | undefined> {
    const existingCourse = this.courses.get(id);
    if (!existingCourse) return undefined;
    
    const updatedCourse: Course = {
      ...existingCourse,
      ...courseUpdate
    };
    
    this.courses.set(id, updatedCourse);
    return updatedCourse;
  }
  
  async deleteCourse(id: number): Promise<boolean> {
    return this.courses.delete(id);
  }
  
  // Module methods
  async getModules(courseId: number): Promise<Module[]> {
    return Array.from(this.modules.values())
      .filter(module => module.courseId === courseId)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }
  
  async getModule(id: number): Promise<Module | undefined> {
    return this.modules.get(id);
  }
  
  async createModule(insertModule: InsertModule): Promise<Module> {
    const id = this.moduleIdCounter++;
    const now = new Date();
    const module: Module = {
      ...insertModule,
      id,
      createdAt: now
    };
    this.modules.set(id, module);
    return module;
  }
  
  async updateModule(id: number, moduleUpdate: Partial<InsertModule>): Promise<Module | undefined> {
    const existingModule = this.modules.get(id);
    if (!existingModule) return undefined;
    
    const updatedModule: Module = {
      ...existingModule,
      ...moduleUpdate
    };
    
    this.modules.set(id, updatedModule);
    return updatedModule;
  }
  
  async deleteModule(id: number): Promise<boolean> {
    return this.modules.delete(id);
  }
  
  // Progress methods
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return Array.from(this.progress.values())
      .filter(progress => progress.userId === userId);
  }
  
  async getModuleProgress(userId: number, moduleId: number): Promise<UserProgress | undefined> {
    return Array.from(this.progress.values())
      .find(progress => progress.userId === userId && progress.moduleId === moduleId);
  }
  
  async getCourseProgress(userId: number, courseId: number): Promise<UserProgress[]> {
    return Array.from(this.progress.values())
      .filter(progress => progress.userId === userId && progress.courseId === courseId);
  }
  
  async createOrUpdateProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    // Check if progress entry already exists
    const existingProgress = Array.from(this.progress.values())
      .find(p => 
        p.userId === insertProgress.userId && 
        p.moduleId === insertProgress.moduleId
      );
    
    if (existingProgress) {
      const updatedProgress: UserProgress = {
        ...existingProgress,
        ...insertProgress
      };
      this.progress.set(existingProgress.id, updatedProgress);
      return updatedProgress;
    } else {
      const id = this.progressIdCounter++;
      const now = new Date();
      // Create explicit object to match UserProgress type
      const newProgress: UserProgress = {
        id,
        userId: insertProgress.userId,
        courseId: insertProgress.courseId,
        moduleId: insertProgress.moduleId,
        completed: insertProgress.completed ?? false,
        completedAt: insertProgress.completedAt || null,
        createdAt: now
      };
      this.progress.set(id, newProgress);
      return newProgress;
    }
  }
}

export const storage = new MemStorage();
